var aboutAnimated, teamAnimated;


$(document).ready(function(){
    $(window).load(function(){
      $('#loader').fadeOut();
    });

	$('#home, .maya .sl-slider-wrapper').height($(window).height());

	$(window).on('beforeunload', function() {
        $(window).scrollTop(0);
    });

    aboutAnimated=false,teamAnimated=false;

    $('.animatable, .timedAnimatable').removeClass('normal');

	$(window).scroll(function(){
        checkScrollLimits();
    })

    $('.menu a').click(function(e){
    	e.preventDefault();
    	$('.menu a').removeClass('current');
    	$(this).addClass('current');
    	target = $(this).attr('href');
    	$('html, body').animate({
        scrollTop: $(target).offset().top
    	}, 1000);
    });

    $('.serviceExplain > div').hover(function(){
        $('.serviceExplain > div').removeClass('hovered');
        $('.serviceDetail').removeClass('display');
        target = Number($(this).data('service'))-1;
        $(this).addClass('hovered');
        $('.serviceDetail:eq('+target+')').addClass('display');
    });

    $(".projects > .thumb").hover(function(){
      $(this).stop().addClass('active');
      },function(){
      $(this).stop().removeClass('active');
    });


    $("#closeOverlay").click(function(){
        $('#masterOverlay').slideUp();
        
    });
    
    loadGallery();
    $('button.submit').click(function(){   
        name=$('.contactform .name').val();  
        email=$('.contactform .email').val();  
        mobile=$('.contactform .phone').val();  
        message=$('.contactform .message').val();
           alert("Thanks! We had recieved your Message. We will get in touch with you soon")
                   $('.contactform .name').val('');  
                   $('.contactform .email').val('');  
                   $('.contactform .phone').val('');  
                   $('.contactform .message').val('');
        $.ajax({
                type: 'get',
                url: 'http://imajination.in/maya_email.php/'+"?name="+name+"&email="+email+"&mobile="+mobile+"&message="+message,
                data: '',
                contentType: "application/jsonp; charset=utf-8",
                traditional: true,
                success: function (data) {
                 //   alert(data); 
                   $('.contactform .name').val('');  
                   $('.contactform .email').val('');  
                   $('.contactform .phone').val('');  
                   $('.contactform .message').val('');
                }
            });
    });

});

function checkScrollLimits() {
	
	if($(window).scrollTop() >= $(window).height()-200 ) {
		$('#header').addClass('header-shrink');
	}
	else {
		$('#header').removeClass('header-shrink');		
	}

    if(!aboutAnimated){
        if($(window).scrollTop() >= $('#about').offset().top-100){
            aboutAnimated = true;
            $('#about .animatable, #about .timedAnimatable1, #about .timedAnimatable2, #about .timedAnimatable3').addClass('normal');
        }
    }
    if(!teamAnimated){
        if($(window).scrollTop() >= $('#team').offset().top){
            teamAnimated = true;
            $('#team .animatable, #team .timedAnimatable1, #team .timedAnimatable2, #team .timedAnimatable3').addClass('normal');
        }
    }
}

function loadGallery(){
      //Loading the Projects from Json
    $.getJSON("projects.txt", function(projects) {
        console.log(projects); 
        projects=projects.Projects;
        for(i=0;i<projects.length;i++){            
            projectContent='';
            projectContent='<div class="col-md-3 col-sm-4 col-xs-6 thumb"><img src="project/'+projects[i].id+'/thumb1.jpg"><div class="hoverlayer"><div><h3>'+projects[i].name+'</h3><span class="hidden-xs"><i class="fa fa-map-marker"></i>'+projects[i].location+'</span><button data-projectid="'+projects[i].id+'" data-fullname="'+projects[i].fullName+'" data-status="'+projects[i].status+'" data-location="'+projects[i].location+'" data-details="'+projects[i].specs+'" data-count="'+projects[i].count+'">View Project</button></div></div></div>';
            $('#portfolio .projects').append(projectContent);
        }

        $(".projects > .thumb").hover(function(){
          $(this).stop().addClass('active');
          },function(){
          $(this).stop().removeClass('active');
        });

        
        $(".hoverlayer button").click(function(){
            projectid = $(this).data('projectid');
            projectName = $(this).data('fullname');
            projectStatus = $(this).data('status');
            projectLocation = $(this).data('location');
            projectSpecs = $(this).data('details');
            count=$(this).data('count');

            $('.portfolio').slideDown();
            $('.portfolio .name').html(projectName);
            $('.portfolio .location').html(projectLocation);
            $('.portfolio .status').html(projectStatus);
            $('.portfolio .specs').html(projectSpecs);
            $('.thumbnailWrapper').empty();
            var content = '';
            for(i=1;i<=count;i++){
                content+='<a class="mayaGallery" rel="group'+projectid+'" href="project/'+projectid+'/'+i+'.jpg"><img src="project/'+projectid+'/thumb'+i+'.jpg" alt=""/></a>';
            }
            $('.thumbnailWrapper').append(content);
            $("a.mayaGallery").fancybox({
                'transitionIn'  :   'elastic',
                'transitionOut' :   'elastic',
                'speedIn'   :   600, 
                'speedOut'  :   200, 
                'overlayShow'   :   false,
                'cyclic'    :   true,
                'showNavArrows' :   true
            })
        });
    });
}